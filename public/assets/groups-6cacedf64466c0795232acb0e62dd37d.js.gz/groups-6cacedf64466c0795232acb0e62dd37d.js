$(function(){
  $('.select2').select2();
  $('.datepicker').datetimepicker({
    "format": "YYYY-MM-DD HH:mm",
    "weekStart": 1,
    "autoclose": true
  });
})
;
